# WAP to display reverse of a number
n = input("Enter a number: ")
print(f"Reverse of {n} = {n[::-1]}")