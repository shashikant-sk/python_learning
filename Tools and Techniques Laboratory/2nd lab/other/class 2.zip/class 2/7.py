# WAP to evaluate the equation y=x^n where n is a non-negative integer.
x = int(input("Enter x: "))
n = int(input("Enter n: "))
print(f"{x}^{n} = {x**n}")